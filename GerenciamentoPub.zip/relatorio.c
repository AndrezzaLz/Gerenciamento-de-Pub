#include "gerenciamentoDePub.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void GerarRelatorioEstoque(Produto produtos[], int totalProdutos) {
    FILE *arquivo = fopen("relatorio_estoque.txt", "w");

    if (arquivo == NULL) {
        printf("Erro ao criar o arquivo de relatório de estoque.\n");
        return;
    }

    fprintf(arquivo, "Relatorio de Estoque:\n\n");
    fprintf(arquivo, "ID\tTipo\t\tQuantidade em Estoque\t\tValor Unit.\t\tValor em Estoque\tNome\n");
    fprintf(arquivo, "----------------------------------------------------------------------------------------\n");

    float valorTotalEstoque = 0.0;
    int totalItensEstoque = 0;

    for (int i = 0; i < totalProdutos; i++) {
        float valorEstoqueProduto = produtos[i].qtdProduto * produtos[i].valor;
        fprintf(arquivo, "%d\t%-10s\t\t\t%d\t\t\t\t\tR$%.2f\t\t\tR$%.3f\t\t\t%-15s\n", produtos[i].id, produtos[i].tipo, produtos[i].qtdProduto, produtos[i].valor, valorEstoqueProduto, produtos[i].nome);

        valorTotalEstoque += valorEstoqueProduto;
        totalItensEstoque += produtos[i].qtdProduto;
    }

    fprintf(arquivo, "----------------------------------------------------------------------------------------\n");
    fprintf(arquivo, "Total de itens em estoque: %d\n", totalItensEstoque);
    fprintf(arquivo, "Valor total em estoque: R$%.2f\n", valorTotalEstoque);

    fclose(arquivo);
    printf("Relatorio de estoque gerado com sucesso.\n");
}

void GerarRelatorioVendas(Produto produtos[], int totalProdutos) {
    FILE *arquivo = fopen("relatorio_vendas.txt", "w");
    FILE *pedidos = fopen("pedidos.txt", "r");

    if (arquivo == NULL || pedidos == NULL) {
        printf("Erro ao criar o arquivo de relatorio de vendas ou ler pedidos.\n");
        return;
    }

    // Array para armazenar quantidade vendida de cada produto
    int vendas[50] = {0}; // Inicializa todas as posições com 0
    
    // Ler o arquivo de pedidos e contar vendas
    char linha[200];
    int id_atual = -1;
    int quantidade_atual = 0;
    
    while (fgets(linha, sizeof(linha), pedidos) != NULL) {
        if (strncmp(linha, "ID: ", 4) == 0) {
            sscanf(linha, "ID: %d", &id_atual);
        }
        else if (strncmp(linha, "Quantidade: ", 11) == 0) {
            sscanf(linha, "Quantidade: %d", &quantidade_atual);
            // Procura o índice do produto com esse ID
            for (int i = 0; i < totalProdutos; i++) {
                if (produtos[i].id == id_atual) {
                    vendas[i] += quantidade_atual;
                    break;
                }
            }
        }
    }

    fprintf(arquivo, "Relatório de Vendas:\n\n");
    fprintf(arquivo, "ID\tTipo\t\tQuantidade Vendida\tValor Unit.\t\tValor Total\t\tNome\n");
    fprintf(arquivo, "----------------------------------------------------------------------------------------\n");

    float valorTotalVendas = 0.0;
    int totalItensVendidos = 0;

    for (int i = 0; i < totalProdutos; i++) {
        if (vendas[i] > 0) {
            float valorTotal = vendas[i] * produtos[i].valor;
            fprintf(arquivo, "%d\t%-10s\t%d\t\t\t\t\tR$%.2f\t\t\tR$%.3f\t\t\t%-20s\n", produtos[i].id, produtos[i].tipo, vendas[i], produtos[i].valor, valorTotal, produtos[i].nome);
            
            valorTotalVendas += valorTotal;
            totalItensVendidos += vendas[i];
        }
    }

    fprintf(arquivo, "----------------------------------------------------------------------------------------\n");
    fprintf(arquivo, "Total de itens vendidos: %d\n", totalItensVendidos);
    fprintf(arquivo, "Valor total das vendas: R$%.2f\n", valorTotalVendas);

    fclose(arquivo);
    fclose(pedidos);
    printf("Relatorio de vendas gerado com sucesso.\n");
}

void relatorio()
{
    int escolha = 0;

    while (escolha != 3)
    {
        printf("\n");
        printf("\nO que voce deseja fazer?\n");
        printf("1. Gerar relatorio de estoque.\n");
        printf("2. Gerar relatorio de vendas.\n");
        printf("3. Sair.\n");
        scanf("%d", &escolha);

        Produto produtos[50];
        int totalProdutos = loadprodutos(produtos, fopen("produtos.txt", "r"));

        switch (escolha)
        {
        case 1:
            GerarRelatorioEstoque(produtos, totalProdutos);
            break;
        case 2:
            GerarRelatorioVendas(produtos, totalProdutos);
            break;
        case 3:
            return;
        default:
            printf("Escolha invalida.\n");
        }
    }
}
