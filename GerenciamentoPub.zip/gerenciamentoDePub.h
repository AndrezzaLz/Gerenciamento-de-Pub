#ifndef GERENCIAMENTODEPUB_H
#define GERENCIAMENTODEPUB_H
#include <stdio.h>

typedef struct {
    int id;
    char nome[50];
    float valor;
    char descricao[100];
    char tipo[20];
    int qtdProduto;
    int qntVendida;
} Produto;

// Funções cadatro de Produtos
void viewprodutos();
int loadprodutos(Produto produtos[], FILE *arquivo);
int buscarid(Produto produtos[], int total, int id);
int editinfo();
void addproduto();
void listarProdutos();
void consultarProdutos();
void estoque();
void cadastro();

typedef struct {
    int codigo;
    int quantidade;
    char produto[50];
    float valor;
    int id;
} Pedido;

// Funções registro de Pedidos
void consultarPedidos();
int contarPedidos(Pedido pedidos[], FILE *arquivo);
float buscarPreco(char *nomeProduto);
int buscarId(char *nomeProduto);
void deletarTudo();
void deletarComanda();
void cadastrarPedido();
void pedido();

// Funções para geração de relatorios
void GerarRelatorioEstoque(Produto produtos[], int totalProdutos);
void GerarRelatorioVendas(Produto produtos[], int totalProdutos);
void relatorio();

#endif