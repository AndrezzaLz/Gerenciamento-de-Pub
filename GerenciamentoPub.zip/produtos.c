#include "gerenciamentoDePub.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void viewprodutos()
{
    FILE *produtos = fopen("produtos.txt", "r");

    if (produtos == NULL)
    {
        printf("Erro ao abrir o arquivo.\n");
        return;
    }

    printf("Esses são todos os produtos já cadastrados:\n\n");
    char linha[200];
    while (fgets(linha, sizeof(linha), produtos) != NULL)
    {
        printf("%s", linha); // le o arquivo linha por linha e exibe cada uma
    }
    printf("\n");

    fclose(produtos);
}

int loadprodutos(Produto produtos[], FILE *arquivo)
{
    int i = 0;
    char linha[200];

    rewind(arquivo); // volta pro inicio do arquivo

    while (fscanf(arquivo, " ID: %d\n", &produtos[i].id) == 1)
    {
        fscanf(arquivo, " Nome: %[^\n]\n", produtos[i].nome);
        fscanf(arquivo, " Valor: %f\n", &produtos[i].valor);
        fscanf(arquivo, " Descrição: %[^\n]\n", produtos[i].descricao);
        fscanf(arquivo, " Tipo: %[^\n]\n", produtos[i].tipo);
        fscanf(arquivo, " Quantidade de produto no estoque: %d\n\n", &produtos[i].qtdProduto); // Lê a quantidade e pula a linha em branco entre registros

        i++; // Incrementa para o próximo produto
    }
    return i; // total de produtos lidos
}

int buscarid(Produto produtos[], int total, int id)
{
    for (int i = 0; i < total; i++)
    {
        if (produtos[i].id == id)
        { // percorre o array ate achar o id
            return i;
        }
    }
    return -1;
}

int editinfo()
{
    viewprodutos();
    Produto produtos[50];
    int id;
    int totalprodutos = 0;

    FILE *arq = fopen("produtos.txt", "r+");
    if (arq == NULL)
    {
        printf("Falha ao abrir o arquivo.\n");
        return -1;
    }

    totalprodutos = loadprodutos(produtos, arq);

    printf("Digite o ID do produto que gostaria de editar:\n");
    scanf("%d", &id);

    int i = buscarid(produtos, totalprodutos, id);
    if (i == -1)
    {
        printf("Produto não encontrado.\n");
        fclose(arq);
        return -1;
    }

    int escolha;
    printf("O que deseja editar?\n1. Nome\n2. Valor\n3. Descrição\n4. Tipo\n5. Quantidade de produto no estoque\n6. Tudo\n7. Excluir produto\n8. Cancelar operação\n");
    scanf("%d", &escolha);

    switch (escolha)
    {
    case 1:
        printf("Novo nome: ");
        getchar();
        fgets(produtos[i].nome, 50, stdin);
        produtos[i].nome[strcspn(produtos[i].nome, "\n")] = '\0';
        break;
    case 2:
        printf("Novo valor: ");
        scanf("%f", &produtos[i].valor);
        break;
    case 3:
        printf("Nova descrição: ");
        getchar();
        fgets(produtos[i].descricao, 100, stdin);
        produtos[i].descricao[strcspn(produtos[i].descricao, "\n")] = '\0';
        break;
    case 4:
        printf("Novo tipo (ex: Bebida, Porção): ");
        getchar();
        fgets(produtos[i].tipo, 20, stdin);
        produtos[i].tipo[strcspn(produtos[i].tipo, "\n")] = '\0';
        break;
    case 5:
        printf("Nova quantidade de produto no estoque: ");
        scanf("%d", &produtos[i].qtdProduto);
        break;
    case 6:
        printf("Novo nome: ");
        getchar();
        fgets(produtos[i].nome, 50, stdin);
        produtos[i].nome[strcspn(produtos[i].nome, "\n")] = '\0';
        printf("Novo valor: ");
        scanf("%f", &produtos[i].valor);
        getchar();
        printf("Nova descrição: ");
        fgets(produtos[i].descricao, 100, stdin);
        produtos[i].descricao[strcspn(produtos[i].descricao, "\n")] = '\0';
        printf("Novo tipo (ex: Bebida, Porção): ");
        fgets(produtos[i].tipo, 20, stdin);
        produtos[i].tipo[strcspn(produtos[i].tipo, "\n")] = '\0';
        break;
    case 7:
        produtos[i].id = -1; // marca como excluído
        break;
    case 8:
        fclose(arq);
        return 0;
    default:
        printf("Opção inválida.\n");
    }

    freopen("produtos.txt", "w", arq); // muda o modo de um arquivo ja aberto
    for (int j = 0; j < totalprodutos; j++)
    {
        if (produtos[j].id != -1)
        {
            fprintf(arq, "ID: %d\nNome: %s\nValor: %.2f\nDescrição: %s\nTipo: %s\nQuantidade de produto no estoque: %d\n\n",
                    produtos[j].id, produtos[j].nome, produtos[j].valor, produtos[j].descricao, produtos[j].tipo, produtos[j].qtdProduto);
        }
    }

    fclose(arq);
    printf("Informações editadas com sucesso.\n");
    return 0;
}

void addproduto()
{
    FILE *arq = fopen("produtos.txt", "a+");
    int newid = 0;
    Produto produtos[50];
    Produto novo;

    if (arq == NULL)
    {
        printf("Erro ao abrir o arquivo.\n");
        return;
    }

    newid = loadprodutos(produtos, arq) + 1; // pega o total de produtos + 1 p ser o id do novo produto (evita id repetido)
    novo.id = newid;

    getchar();
    printf("Qual o nome do produto que gostaria de adicionar?\n");
    fgets(novo.nome, 50, stdin);
    novo.nome[strcspn(novo.nome, "\n")] = '\0'; // tirando o \n

    printf("Qual o valor desse produto?\n");
    scanf("%f", &novo.valor);
    getchar();

    printf("Insira uma breve descrição sobre o produto.\n");
    fgets(novo.descricao, 100, stdin);
    novo.descricao[strcspn(novo.descricao, "\n")] = '\0';

    printf("Qual o tipo do produto (ex: Bebida, Porção)?\n");
    fgets(novo.tipo, 20, stdin);
    novo.tipo[strcspn(novo.tipo, "\n")] = '\0';

    printf("Qual a quantidade desse produto no estoque?\n");
    scanf("%d", &novo.qtdProduto);
    getchar();

    fprintf(arq, "ID: %d\nNome: %s\nValor: %.2f\nDescrição: %s\nTipo: %s\nQuantidade de produto no estoque: %d\n\n", novo.id, novo.nome, novo.valor, novo.descricao, novo.tipo, novo.qtdProduto);

    fclose(arq);
    printf("Produto cadastrado com sucesso!\n");
}

void listarProdutos()
{
    FILE *produtos = fopen("produtos.txt", "r");

    if (produtos == NULL)
    {
        printf("Erro ao abrir o arquivo.\n");
        return;
    }

    printf("Esses são todos os produtos do estoque:\n\n");
    char linha[200];
    while (fgets(linha, sizeof(linha), produtos) != NULL)
    {
        printf("%s", linha); // le o arquivo linha por linha e exibe cada uma
    }
    printf("\n");

    fclose(produtos);
}

void consultarProdutos()
{
    FILE *arqProdutos = fopen("produtos.txt", "r");
    if (arqProdutos == NULL)
    {
        printf("Erro ao abrir o arquivo.\n");
        return;
    }

    Produto produtos[50];
    int totalProdutos = loadprodutos(produtos, arqProdutos);
    fclose(arqProdutos);

    int escolha = 0;

    while (escolha != 5)
    {
        printf("\nComo deseja consultar o produto:\n");
        printf("1. ID\n");
        printf("2. Sair;\n");
        scanf("%d", &escolha);

        switch (escolha)
        {
        case 1:
        {
            int idBusca, encontrado = 0; // Coloquei as declarações dentro de um bloco
            printf("Digite o ID do produto: ");
            scanf("%d", &idBusca);
            for (int i = 0; i < totalProdutos; i++)
            {
                if (produtos[i].id == idBusca)
                {
                    printf("\nProduto encontrado com o ID: %d:\nNome: %s - Valor: %.2f - Descrição: %s - Tipo: %s - Quantidade no estoque: %d\n",
                           produtos[i].id, produtos[i].nome, produtos[i].valor, produtos[i].descricao, produtos[i].tipo, produtos[i].qtdProduto);
                    encontrado = 1;
                    break;
                }
            }
            if (!encontrado)
            {
                printf("Produto não encontrado.\n");
            }
            break;
        }
        case 2:
            return;
        default:
            printf("Escolha inválida.\n");
        }
    }
}

void estoque()
{
    int escolha = 0;

    while (escolha != 5)
    {
        printf("\nMenu de Gerenciamento de Estoque:\n");
        printf("1. Listar os produtos do estoque\n");
        printf("2. Consultar produtos do estoque\n");
        printf("3. Sair;\n");
        scanf("%d", &escolha);

        switch (escolha)
        {
        case 1:
            listarProdutos();
            break;
        case 2:
            consultarProdutos();
            break;
        case 3:
            return;
        default:
            printf("Escolha inválida.\n");
        }
    }
}

void cadastro()
{
    int escolha = 0;

    while (escolha != 4)
    {
        printf("O que você deseja fazer?\n1. Adicionar novo produto;\n2. Editar informações já existentes;\n3. Visualizar produtos cadastrados;\n4. Gerenciar estoque;\n5. Continuar.\n");
        scanf("%d", &escolha);

        switch (escolha)
        {
        case 1:
            addproduto();
            break;
        case 2:
            editinfo();
            break;
        case 3:
            viewprodutos();
            break;
        case 4:
            estoque();
            break;
        case 5:
            return;
        default:
            printf("Escolha inválida.\n");
        }
    }
}