#include "gerenciamentoDePub.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main()
{
    int escolha = 0;

    while (escolha != 4)
    {
        printf("\n");
        printf("\nO que voce deseja fazer?\n");
        printf("1. Menu de cadastro e estoque.\n");
        printf("2. Menu de pedidos.\n");
        printf("3. Menu dos relatorios.\n");
        printf("4. Sair.\n");
        scanf("%d", &escolha);

        switch (escolha)
        {
        case 1:
            cadastro();
            break;
        case 2:
            pedido();
            break;
        case 3:
            relatorio();
            break;
        case 4:
            return 0;
        default:
            printf("Escolha invalida.\n");
        }
    }

    return 0;
}